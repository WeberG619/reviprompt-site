# MEP SYSTEM PROMPTS (25 total)

## M1. HVAC SYSTEMS (8 prompts)

### M1.01 - Residential HVAC Load Calculator
```
Calculate HVAC loads for residential projects:
1. Perform Manual J load calculation for each room
2. Calculate whole-house heating and cooling loads
3. Size HVAC equipment based on calculated loads
4. Design ductwork sizing and layout
5. Check energy code compliance (13 SEER minimum)
6. Generate HVAC load calculation report and equipment schedule

Include: Single-family, townhouse, and small multifamily
Reference: ACCA Manual J, S, and D calculation procedures
Focus on: Florida climate zone and humidity considerations
```

### M1.02 - Commercial HVAC System Designer
```
Design commercial HVAC systems:
1. Calculate commercial building HVAC loads
2. Select appropriate HVAC system type (VAV, FCU, etc.)
3. Size central plant equipment (chillers, boilers, cooling towers)
4. Design air distribution and ductwork systems
5. Check ventilation requirements (ASHRAE 62.1)
6. Generate HVAC system design documentation

Include: Office buildings, retail, restaurants, hotels
Reference: ASHRAE standards and Florida Energy Conservation Code
Focus on: Energy efficiency and indoor air quality
```

### M1.03 - Hospital and Healthcare HVAC Specialist
```
Design healthcare facility HVAC systems:
1. Check infection control and air quality requirements
2. Design negative and positive pressure room systems
3. Calculate medical gas and laboratory ventilation
4. Size emergency power for critical HVAC systems
5. Check humidity and temperature control requirements
6. Generate healthcare HVAC compliance documentation

Include: Hospitals, clinics, surgery centers, nursing homes
Reference: ASHRAE 170, FGI Guidelines, and Joint Commission standards
Focus on: Patient safety and infection control
```

### M1.04 - Energy Recovery and Efficiency Optimizer
```
Optimize HVAC energy efficiency and recovery:
1. Calculate energy recovery ventilator (ERV) benefits
2. Design variable speed and VFD applications
3. Analyze heat pump vs conventional system efficiency
4. Calculate solar cooling and renewable integration
5. Design building automation and control systems
6. Generate energy efficiency analysis and ROI calculations

Include: Demand control ventilation and economizer cycles
Reference: ASHRAE 90.1 and Florida Energy Conservation Code
Focus on: Cost-effective energy efficiency measures
```

### M1.05 - Indoor Air Quality and Ventilation Designer
```
Design indoor air quality and ventilation systems:
1. Calculate outdoor air ventilation requirements
2. Design air filtration and purification systems
3. Check exhaust ventilation requirements
4. Design kitchen and bathroom ventilation
5. Calculate contaminant removal and dilution
6. Generate indoor air quality compliance documentation

Include: COVID-19 air quality considerations and MERV filtration
Reference: ASHRAE 62.1, 62.2, and indoor air quality standards
Focus on: Healthy indoor environments and occupant comfort
```

### M1.06 - Specialty Environment HVAC Designer
```
Design HVAC for specialty environments:
1. Design cleanroom HVAC and filtration systems
2. Calculate server room and data center cooling
3. Design laboratory fume hood and exhaust systems
4. Calculate pool and spa dehumidification systems
5. Design wine cellar and cold storage HVAC
6. Generate specialty HVAC system documentation

Include: Museums, archives, manufacturing, and research facilities
Reference: Industry-specific HVAC standards and requirements
Focus on: Process requirements and environmental control
```

### M1.07 - HVAC Equipment Selection and Specification
```
Select and specify HVAC equipment:
1. Compare equipment efficiency ratings and performance
2. Verify equipment capacity and application suitability
3. Check warranty and service availability
4. Calculate life cycle cost and energy savings
5. Verify installation and maintenance requirements
6. Generate equipment specification and procurement documentation

Include: Residential and commercial equipment manufacturers
Reference: AHRI certification and Energy Star requirements
Focus on: Reliable and efficient equipment selection
```

### M1.08 - HVAC System Commissioning Planner
```
Plan HVAC system commissioning and testing:
1. Develop commissioning scope and procedures
2. Create system startup and testing checklists
3. Plan performance testing and verification
4. Develop training and documentation requirements
5. Create warranty and maintenance transition procedures
6. Generate commissioning plan and documentation

Include: Both new construction and existing building commissioning
Reference: ASHRAE Guideline 0 and 1.1 commissioning standards
Focus on: System performance and operational efficiency
```

## M2. ELECTRICAL SYSTEMS (8 prompts)

### M2.01 - Electrical Load Analysis and Panel Schedule Generator
```
Calculate electrical loads and generate panel schedules:
1. Calculate lighting loads by room and building type
2. Calculate receptacle and equipment loads
3. Size electrical panels and distribution equipment
4. Generate detailed panel schedules and load calculations
5. Check voltage drop and circuit protection
6. Generate electrical load analysis report

Include: Residential, commercial, and industrial load types
Reference: NEC Article 220 Branch-Circuit, Feeder, and Service Calculations
Focus on: Accurate load calculations and code compliance
```

### M2.02 - Emergency Power and Life Safety Electrical Designer
```
Design emergency power and life safety electrical systems:
1. Calculate emergency lighting and exit sign requirements
2. Size emergency generators and transfer switches
3. Design fire alarm and mass notification systems
4. Calculate UPS and battery backup requirements
5. Design emergency communication systems
6. Generate life safety electrical system documentation

Include: Hospitals, high-rises, assembly occupancies
Reference: NEC Article 700, 701, 702 Emergency Systems
Focus on: Reliable emergency power and life safety compliance
```

### M2.03 - Commercial Lighting Design and Controls
```
Design commercial lighting and control systems:
1. Calculate lighting levels and uniformity
2. Select efficient LED lighting and controls
3. Design daylight harvesting and occupancy controls
4. Calculate lighting power density compliance
5. Design emergency and security lighting
6. Generate lighting design and energy compliance documentation

Include: Office, retail, warehouse, and exterior lighting
Reference: IES Lighting Handbook and ASHRAE 90.1
Focus on: Energy efficiency and visual comfort
```

### M2.04 - Data and Communication Systems Designer
```
Design data and communication infrastructure:
1. Design structured cabling and fiber optic systems
2. Calculate data center power and cooling requirements
3. Design wireless network infrastructure
4. Plan security and surveillance systems
5. Design audiovisual and presentation systems
6. Generate data and communication system documentation

Include: Office buildings, hotels, schools, and healthcare
Reference: TIA/EIA standards and manufacturer specifications
Focus on: Future-ready technology infrastructure
```

### M2.05 - Motor Control and Industrial Electrical
```
Design motor control and industrial electrical systems:
1. Calculate motor loads and control requirements
2. Size motor starters and variable frequency drives
3. Design power factor correction systems
4. Calculate short circuit and arc flash analysis
5. Design grounding and electrical safety systems
6. Generate motor control and safety documentation

Include: Manufacturing, processing, and mechanical equipment
Reference: NEC Article 430 Motors and Motor Controllers
Focus on: Safety and reliable motor operation
```

### M2.06 - Renewable Energy and Sustainability
```
Design renewable energy and sustainable electrical systems:
1. Calculate solar photovoltaic system sizing
2. Design energy storage and battery systems
3. Calculate electric vehicle charging infrastructure
4. Design microgrid and grid-tie systems
5. Calculate renewable energy incentives and payback
6. Generate renewable energy system documentation

Include: Grid-tied and off-grid renewable systems
Reference: NEC Article 690 Solar Photovoltaic Systems
Focus on: Sustainable and resilient electrical systems
```

### M2.07 - Healthcare and Special Occupancy Electrical
```
Design electrical systems for healthcare and special occupancies:
1. Design hospital-grade electrical systems
2. Calculate isolated power systems for operating rooms
3. Design emergency power for life support equipment
4. Check electrical requirements for medical equipment
5. Design fire pump and special equipment power
6. Generate healthcare electrical compliance documentation

Include: Hospitals, surgery centers, data centers
Reference: NEC Article 517 Health Care Facilities
Focus on: Patient safety and critical system reliability
```

### M2.08 - Electrical Code Compliance and Safety
```
Verify electrical code compliance and safety:
1. Check electrical installation code compliance
2. Verify electrical safety and OSHA requirements
3. Calculate arc flash and electrical safety analysis
4. Check grounding and bonding requirements
5. Verify electrical equipment ratings and applications
6. Generate electrical code compliance and safety report

Include: Construction safety and operational safety
Reference: NEC, OSHA, and NFPA 70E electrical safety standards
Focus on: Worker and occupant electrical safety
```

## M3. PLUMBING SYSTEMS (9 prompts)

### M3.01 - Plumbing Fixture and Water System Designer
```
Design plumbing fixture and water distribution systems:
1. Calculate plumbing fixture units and water demand
2. Size water distribution piping and pumps
3. Calculate hot water generation and distribution
4. Design water pressure and flow requirements
5. Calculate water conservation and efficiency measures
6. Generate plumbing system design and fixture schedules

Include: Residential, commercial, and institutional projects
Reference: IPC International Plumbing Code and fixture manufacturers
Focus on: Adequate water supply and pressure throughout building
```

### M3.02 - Sanitary Sewer and Waste System Designer
```
Design sanitary sewer and waste systems:
1. Calculate drainage fixture units and pipe sizing
2. Design sanitary sewer and vent systems
3. Calculate grease trap and interceptor requirements
4. Design sewage ejector and pump systems
5. Check sewer connection and municipal requirements
6. Generate sanitary sewer system design documentation

Include: Gravity and pressurized sewer systems
Reference: IPC International Plumbing Code and local sewer authorities
Focus on: Proper drainage and waste removal
```

### M3.03 - Storm Water Management and Drainage
```
Design storm water management and drainage systems:
1. Calculate rainfall intensity and runoff rates
2. Design roof drainage and downspout systems
3. Calculate storm water detention and retention
4. Design underground storm drainage systems
5. Check flood protection and drainage requirements
6. Generate storm water management plan and calculations

Include: Green infrastructure and LID practices
Reference: Local drainage criteria and DEP requirements
Focus on: Flood protection and environmental compliance
```

### M3.04 - Fire Protection and Sprinkler Systems
```
Design fire protection and sprinkler systems:
1. Calculate sprinkler system water demand
2. Design automatic sprinkler coverage and layout
3. Calculate fire pump and water storage requirements
4. Design standpipe and fire department connection
5. Check fire protection water supply adequacy
6. Generate fire protection system design and hydraulic calculations

Include: Wet, dry, and pre-action sprinkler systems
Reference: NFPA 13, 14, and 20 fire protection standards
Focus on: Life safety and property protection
```

### M3.05 - Medical Gas and Laboratory Plumbing
```
Design medical gas and laboratory plumbing systems:
1. Design medical gas distribution (oxygen, nitrous oxide, vacuum)
2. Calculate laboratory water and waste requirements
3. Design emergency shower and eyewash systems
4. Calculate compressed air and specialty gas systems
5. Design medical equipment water and drainage
6. Generate medical gas and laboratory plumbing documentation

Include: Hospitals, clinics, research facilities, manufacturing
Reference: NFPA 99 Health Care Facilities and laboratory standards
Focus on: Patient safety and laboratory functionality
```

### M3.06 - Pool and Spa Mechanical Systems
```
Design pool and spa mechanical systems:
1. Calculate pool and spa water circulation requirements
2. Design filtration and chemical treatment systems
3. Calculate heating and cooling system requirements
4. Design automatic control and monitoring systems
5. Check health department and safety requirements
6. Generate pool and spa mechanical system documentation

Include: Residential and commercial pools and spas
Reference: NSPF standards and local health department requirements
Focus on: Water quality and bather safety
```

### M3.07 - Irrigation and Landscape Water Systems
```
Design irrigation and landscape water systems:
1. Calculate landscape water requirements and ET rates
2. Design efficient sprinkler and drip irrigation systems
3. Calculate pump and pressure requirements
4. Design water conservation and smart control systems
5. Check water use permits and restrictions
6. Generate irrigation system design and water budget

Include: Residential and commercial landscape irrigation
Reference: IA and EPA water efficiency standards
Focus on: Water conservation and landscape health
```

### M3.08 - Grease Waste and Kitchen Plumbing
```
Design grease waste and commercial kitchen plumbing:
1. Calculate grease production and interceptor sizing
2. Design kitchen equipment drainage and venting
3. Calculate hot water demand for commercial kitchens
4. Design pot washing and ware washing systems
5. Check health department and environmental requirements
6. Generate kitchen plumbing and grease waste documentation

Include: Restaurants, hotels, institutional kitchens
Reference: PDI and health department grease waste standards
Focus on: Environmental protection and operational efficiency
```

### M3.09 - Water Conservation and Sustainability
```
Design water conservation and sustainable plumbing systems:
1. Calculate water use reduction and efficiency measures
2. Design rainwater harvesting and reuse systems
3. Calculate graywater treatment and reuse systems
4. Design water-efficient fixtures and fittings
5. Calculate water conservation incentives and rebates
6. Generate water conservation plan and documentation

Include: Green building and LEED water efficiency credits
Reference: EPA WaterSense and green building standards
Focus on: Sustainable water use and conservation
```