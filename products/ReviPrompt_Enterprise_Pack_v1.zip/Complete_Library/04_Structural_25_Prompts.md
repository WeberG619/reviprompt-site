# STRUCTURAL ENGINEERING PROMPTS (25 total)

## S1. FOUNDATION SYSTEMS (8 prompts)

### S1.01 - Florida Foundation Design Specialist
```
Design foundations for Florida conditions:
1. Analyze soil conditions and bearing capacity
2. Design spread footings for varying soil conditions
3. Calculate pile foundations for weak soils
4. Check scour and erosion protection requirements
5. Design flood-resistant foundation systems
6. Generate foundation design calculations and details

Include: Hurricane and flood design requirements
Reference: Florida Building Code Chapter 18 and IBC Chapter 18
Focus on: Coastal and inland foundation challenges
```

### S1.02 - Deep Foundation and Pile Design
```
Design deep foundation and pile systems:
1. Calculate pile capacity and settlement
2. Design driven pile and drilled shaft foundations
3. Calculate pile group effects and load distribution
4. Design pile caps and grade beams
5. Check lateral pile capacity and deflection
6. Generate pile foundation design and installation specifications

Include: Concrete, steel, and timber pile systems
Reference: IBC Chapter 18 and ACI 543R Deep Foundation Guide
Focus on: Reliable load transfer to competent soil/rock
```

### S1.03 - Shallow Foundation and Footing Designer
```
Design shallow foundations and footings:
1. Calculate footing size for wall and column loads
2. Check bearing pressure and settlement
3. Design reinforcement for spread footings
4. Calculate frost protection and depth requirements
5. Design foundation drainage and waterproofing
6. Generate footing design calculations and details

Include: Strip footings, isolated footings, and mat foundations
Reference: ACI 318 and IBC Chapter 18 foundation requirements
Focus on: Economical and adequate shallow foundation design
```

### S1.04 - Retaining Wall and Earth Pressure Designer
```
Design retaining walls and earth pressure systems:
1. Calculate earth pressure and surcharge loads
2. Design gravity and cantilever retaining walls
3. Calculate stability and overturning resistance
4. Design reinforcement and structural elements
5. Design drainage and waterproofing systems
6. Generate retaining wall design and construction details

Include: Cast-in-place, precast, and segmental block walls
Reference: ACI 318 and geotechnical engineering principles
Focus on: Stable and durable earth retention systems
```

### S1.05 - Basement and Below-Grade Structure Designer
```
Design basement and below-grade structures:
1. Calculate hydrostatic and earth pressure loads
2. Design basement walls and floor slabs
3. Calculate waterproofing and drainage requirements
4. Design structural connections to superstructure
5. Check flotation and uplift resistance
6. Generate below-grade structural design and details

Include: Full and partial basements, mechanical vaults
Reference: ACI 318 and waterproofing industry standards
Focus on: Dry and structurally sound below-grade spaces
```

### S1.06 - Slab-on-Grade and Floor Slab Designer
```
Design slab-on-grade and elevated floor slabs:
1. Calculate slab thickness for loads and soil conditions
2. Design reinforcement for temperature and shrinkage
3. Calculate joint spacing and sealant requirements
4. Design vapor barriers and insulation
5. Check flatness and levelness requirements
6. Generate slab design and construction specifications

Include: Residential, commercial, and industrial slabs
Reference: ACI 302 and ACI 360 slab design guides
Focus on: Crack control and long-term performance
```

### S1.07 - Seismic and Lateral Foundation Design
```
Design foundations for seismic and lateral loads:
1. Calculate seismic base shear and overturning
2. Design foundation for lateral load resistance
3. Calculate soil-structure interaction effects
4. Design tie beams and foundation connectivity
5. Check liquefaction and seismic settlement
6. Generate seismic foundation design and details

Include: Moment-resisting and braced frame foundations
Reference: ASCE 7 and IBC seismic design requirements
Focus on: Earthquake-resistant foundation systems
```

### S1.08 - Foundation Repair and Strengthening
```
Design foundation repair and strengthening systems:
1. Evaluate existing foundation capacity and condition
2. Design underpinning and foundation strengthening
3. Calculate load transfer and construction sequence
4. Design temporary support during construction
5. Check compatibility with existing structure
6. Generate foundation repair design and specifications

Include: Settlement repair, capacity increase, and code upgrades
Reference: ACI and industry foundation repair standards
Focus on: Cost-effective foundation improvements
```

## S2. FRAMING SYSTEMS (8 prompts)

### S2.01 - Wood Frame Construction Designer
```
Design wood frame structural systems:
1. Calculate lumber and engineered wood member sizes
2. Design floor joist and beam systems
3. Calculate roof rafter and truss systems
4. Design shear walls and lateral bracing
5. Check connection and fastener requirements
6. Generate wood frame construction details

Include: Platform frame, balloon frame, and post-and-beam
Reference: NDS Wood Construction and IRC/IBC wood provisions
Focus on: Efficient and code-compliant wood framing
```

### S2.02 - Steel Frame Construction Designer
```
Design steel frame structural systems:
1. Calculate steel beam and column sizes
2. Design moment connections and braced frames
3. Calculate lateral load resistance systems
4. Design steel deck and composite floor systems
5. Check deflection and vibration requirements
6. Generate steel frame design and connection details

Include: Wide flange, HSS, and light gauge steel framing
Reference: AISC Steel Construction Manual and specifications
Focus on: Efficient and economical steel frame design
```

### S2.03 - Concrete Frame Construction Designer
```
Design reinforced concrete frame systems:
1. Calculate concrete beam and column sizes
2. Design reinforcement for flexure and shear
3. Calculate slab systems (one-way, two-way, flat plate)
4. Design moment frames and shear walls
5. Check deflection and crack control
6. Generate concrete frame design and details

Include: Cast-in-place and precast concrete systems
Reference: ACI 318 Building Code Requirements for Structural Concrete
Focus on: Durable and fire-resistant concrete construction
```

### S2.04 - Masonry Construction Designer
```
Design masonry structural systems:
1. Calculate masonry wall design for gravity and lateral loads
2. Design reinforced masonry elements
3. Calculate masonry veneer and cavity wall systems
4. Design masonry lintels and structural elements
5. Check thermal and moisture considerations
6. Generate masonry construction details and specifications

Include: Concrete masonry, clay brick, and stone masonry
Reference: TMS 402/602 Masonry Standards and IBC masonry provisions
Focus on: Durable and weather-resistant masonry construction
```

### S2.05 - Hybrid and Mixed Construction Systems
```
Design hybrid and mixed construction systems:
1. Analyze different material combinations and interfaces
2. Design steel-concrete composite systems
3. Calculate wood-steel hybrid frame systems
4. Design masonry and steel/concrete combinations
5. Check compatibility and connection requirements
6. Generate mixed construction design and details

Include: Podium construction, tilt-up with steel, and timber-steel
Reference: Multiple material standards and connection requirements
Focus on: Optimized construction using multiple materials
```

### S2.06 - Cold-Formed Steel and Light Gauge Design
```
Design cold-formed steel structural systems:
1. Calculate cold-formed steel member capacities
2. Design light gauge steel floor and roof systems
3. Calculate lateral load resistance for light gauge systems
4. Design connections and fastening systems
5. Check thermal bridging and energy considerations
6. Generate cold-formed steel design and details

Include: Residential and commercial light gauge applications
Reference: AISI Cold-Formed Steel Design Specifications
Focus on: Efficient and lightweight steel construction
```

### S2.07 - Prefabricated and Modular Structure Design
```
Design prefabricated and modular structural systems:
1. Calculate modular unit structural requirements
2. Design inter-module connections and transfer systems
3. Calculate transportation and erection loads
4. Design factory-built structural components
5. Check quality control and inspection requirements
6. Generate prefabricated construction specifications

Include: Volumetric modular, panelized, and component systems
Reference: Industry standards and building code provisions
Focus on: Factory quality and efficient site assembly
```

### S2.08 - Renovation and Structural Modification
```
Design structural renovations and modifications:
1. Evaluate existing structural capacity and condition
2. Design structural modifications and additions
3. Calculate load redistribution and temporary support
4. Design new structural elements and connections
5. Check code compliance for alterations
6. Generate renovation structural design and phasing

Include: Structural strengthening, additions, and alterations
Reference: Building codes for existing structures and IEBC
Focus on: Cost-effective structural improvements
```

## S3. LATERAL SYSTEMS (9 prompts)

### S3.01 - Hurricane and Wind Load Designer
```
Design structures for hurricane and high wind loads:
1. Calculate wind loads per ASCE 7 and Florida Building Code
2. Design wind-resistant framing and connections
3. Calculate building envelope design pressures
4. Design hurricane shutters and impact protection
5. Check roof uplift and attachment requirements
6. Generate hurricane design calculations and details

Include: HVHZ (High Velocity Hurricane Zone) requirements
Reference: ASCE 7, Florida Building Code, and FEMA guidelines
Focus on: Life safety and property protection in hurricanes
```

### S3.02 - Seismic Design and Earthquake Resistance
```
Design structures for seismic loads:
1. Calculate seismic base shear and distribution
2. Design seismic force-resisting systems
3. Calculate drift and displacement requirements
4. Design seismic detailing and connections
5. Check soil-structure interaction effects
6. Generate seismic design calculations and details

Include: Special moment frames, braced frames, and shear walls
Reference: ASCE 7 and IBC seismic design provisions
Focus on: Life safety and collapse prevention in earthquakes
```

### S3.03 - Shear Wall and Braced Frame Designer
```
Design shear walls and braced frame systems:
1. Calculate lateral load distribution to vertical elements
2. Design concrete and masonry shear walls
3. Calculate steel braced frame systems
4. Design connections and anchorage systems
5. Check overturning and sliding resistance
6. Generate lateral system design and details

Include: Special and ordinary moment frames and shear walls
Reference: ACI 318, AISC, and masonry design standards
Focus on: Efficient lateral load resistance systems
```

### S3.04 - Diaphragm and Horizontal Distribution
```
Design diaphragms and horizontal load distribution:
1. Calculate diaphragm forces and design requirements
2. Design wood, steel, and concrete diaphragms
3. Calculate collector and drag strut requirements
4. Design diaphragm-to-wall connections
5. Check diaphragm flexibility and distribution assumptions
6. Generate diaphragm design calculations and details

Include: Flexible and rigid diaphragm analysis
Reference: ASCE 7 and material-specific design standards
Focus on: Reliable horizontal load transfer to vertical elements
```

### S3.05 - Torsion and Irregular Building Analysis
```
Analyze buildings with torsion and irregularities:
1. Calculate torsional irregularity and eccentricity
2. Analyze plan and vertical irregularities
3. Calculate accidental and inherent torsion
4. Design for increased force and drift requirements
5. Check need for dynamic analysis procedures
6. Generate irregular building analysis and design

Include: Plan and vertical irregularities per ASCE 7
Reference: ASCE 7 and building code irregular building provisions
Focus on: Safe design of complex and irregular structures
```

### S3.06 - Base Isolation and Damping Systems
```
Design base isolation and energy dissipation systems:
1. Calculate base isolation system requirements
2. Design isolator and damper specifications
3. Calculate reduced seismic forces and displacements
4. Design superstructure and isolation interface
5. Check wind resistance and service loads
6. Generate base isolation design and specifications

Include: Lead-rubber bearings, friction pendulum, and dampers
Reference: ASCE 7 and industry isolation system standards
Focus on: Enhanced seismic performance and occupant comfort
```

### S3.07 - Progressive Collapse and Robustness
```
Design for progressive collapse resistance:
1. Analyze structural robustness and redundancy
2. Design alternate load paths for member removal
3. Calculate dynamic increase factors and ductility
4. Design robust connections and continuity
5. Check blast and abnormal load resistance
6. Generate progressive collapse analysis and design

Include: Government and high-risk building requirements
Reference: GSA and DoD progressive collapse criteria
Focus on: Structural integrity under abnormal loads
```

### S3.08 - Vibration and Dynamic Analysis
```
Analyze structural vibrations and dynamic response:
1. Calculate natural periods and mode shapes
2. Analyze floor vibration and human comfort
3. Calculate equipment and machinery vibration isolation
4. Design tuned mass dampers and vibration control
5. Check wind-induced vibration and comfort
6. Generate vibration analysis and mitigation design

Include: Pedestrian-induced vibration and equipment vibration
Reference: AISC Design Guide 11 and vibration standards
Focus on: Occupant comfort and equipment performance
```

### S3.09 - Retrofit and Seismic Strengthening
```
Design seismic retrofit and strengthening systems:
1. Evaluate existing building seismic deficiencies
2. Design retrofit systems (bracing, shear walls, dampers)
3. Calculate strengthening member and connection requirements
4. Design phased construction and temporary support
5. Check code compliance for retrofit projects
6. Generate seismic retrofit design and specifications

Include: Unreinforced masonry, concrete, and steel retrofits
Reference: ASCE 41 and local retrofit ordinances
Focus on: Cost-effective seismic risk reduction
```