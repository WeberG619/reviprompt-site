# BUILDING CODE ANALYSIS PROMPTS (30 total)

## B1. FLORIDA BUILDING CODE SPECIALISTS (10 prompts)

### B1.01 - Hurricane Design Compliance Checker
```
Analyze project for Florida hurricane design requirements:
1. Check wind speed requirements for [COUNTY] location
2. Verify building envelope design pressure ratings
3. Check window and door impact resistance requirements
4. Verify roof tie-down and uplift resistance
5. Check garage door and opening protection
6. Generate hurricane compliance report with details

Reference: Florida Building Code Chapter 16 - Structural Design
Include HVHZ (High Velocity Hurricane Zone) requirements if applicable.
Target: Residential and commercial buildings in hurricane zones.
```

### B1.02 - Flood Zone Compliance Analyzer
```
Verify flood zone design compliance for Florida projects:
1. Determine Base Flood Elevation (BFE) for site
2. Check lowest floor elevation requirements
3. Verify flood-resistant construction methods
4. Check utility and equipment elevation requirements
5. Verify breakaway wall and enclosure compliance
6. Generate flood compliance certification documentation

Reference: FEMA flood maps and Florida Building Code Section 1612
Include substantial improvement and substantial damage criteria.
Focus on coastal and riverine flood zones.
```

### B1.03 - Energy Conservation Code Optimizer
```
Optimize design for Florida Energy Conservation Code:
1. Calculate building envelope thermal performance
2. Check HVAC system efficiency requirements
3. Verify lighting power density limits
4. Check water heating efficiency requirements
5. Analyze renewable energy compliance options
6. Generate energy compliance report with recommendations

Reference: Florida Energy Conservation Code based on IECC
Include both prescriptive and performance path options.
Target cost-effective energy efficiency strategies.
```

### B1.04 - Accessibility Code Comprehensive Checker
```
Verify comprehensive accessibility compliance:
1. Check Florida Accessibility Code vs ADA requirements
2. Verify accessible route analysis and documentation
3. Check parking and passenger drop-off compliance
4. Verify bathroom and facility accessibility
5. Check signage and communication requirements
6. Generate accessibility compliance certification

Reference: Florida Accessibility Code and 2010 ADA Standards
Include Fair Housing Act requirements for residential projects.
Focus on both new construction and alterations.
```

### B1.05 - Fire Safety and Prevention Code Analyzer
```
Analyze fire safety compliance for Florida projects:
1. Check occupancy classification and fire separations
2. Verify egress capacity and travel distance requirements
3. Check fire-rated assembly and protection requirements
4. Verify fire protection system requirements
5. Check emergency access and fire department requirements
6. Generate fire safety compliance report

Reference: Florida Fire Prevention Code and International Fire Code
Include wildfire protection requirements for interface areas.
Focus on life safety and property protection.
```

### B1.06 - Coastal Construction Compliance Checker
```
Verify coastal construction requirements:
1. Check Coastal Construction Control Line compliance
2. Verify dune and vegetation protection requirements
3. Check sea turtle lighting protection measures
4. Verify coastal erosion and setback requirements
5. Check storm surge and wave action protection
6. Generate coastal compliance documentation

Reference: Florida Coastal Construction Control Line Program
Include Department of Environmental Protection requirements.
Focus on environmental protection and storm resistance.
```

### B1.07 - High-Rise Building Code Analyzer
```
Analyze high-rise building code requirements:
1. Check fire and life safety requirements for tall buildings
2. Verify elevator and emergency egress requirements
3. Check wind load and structural requirements
4. Verify fire protection and suppression systems
5. Check emergency communication and lighting systems
6. Generate high-rise compliance comprehensive report

Reference: Florida Building Code Chapter 4 - Special Detailed Requirements
Include International Building Code high-rise provisions.
Focus on buildings over 75 feet in height.
```

### B1.08 - Existing Building Code Compliance
```
Navigate existing building renovation requirements:
1. Determine alteration vs change of use requirements
2. Check historic building code alternatives
3. Verify accessibility upgrade requirements
4. Check structural and seismic upgrade requirements
5. Analyze cost vs benefit of code upgrades
6. Generate existing building compliance strategy

Reference: Florida Existing Building Code and International Existing Building Code
Include historic preservation considerations.
Focus on cost-effective compliance strategies.
```

### B1.09 - Special Occupancy Requirements Checker
```
Verify special occupancy code requirements:
1. Check assembly occupancy egress and capacity
2. Verify educational facility requirements
3. Check healthcare facility code requirements
4. Verify detention and correctional facility requirements
5. Check hazardous occupancy requirements
6. Generate special occupancy compliance report

Reference: Florida Building Code Chapters 3 and 4
Include occupancy classification and mixed-use requirements.
Focus on specific use group requirements and safety.
```

### B1.10 - Building Materials and Methods Validator
```
Validate building materials and construction methods:
1. Check product approval and certification requirements
2. Verify alternative materials and methods procedures
3. Check testing and quality assurance requirements
4. Verify installation and inspection requirements
5. Check warranty and maintenance requirements
6. Generate materials compliance documentation

Reference: Florida Building Code Chapters 6-10
Include Florida Product Approval database verification.
Focus on code-compliant and hurricane-resistant materials.
```

## B2. LIFE SAFETY & EGRESS (10 prompts)

### B2.01 - Comprehensive Egress Calculator
```
Calculate and verify egress requirements for all occupancies:
1. Determine occupant load for each space and use
2. Calculate required egress capacity (doors, corridors, stairs)
3. Verify egress travel distance limitations
4. Check egress width and accessibility requirements
5. Verify exit discharge and exterior egress requirements
6. Generate egress analysis report with calculations

Include assembly, business, educational, and residential occupancies.
Reference: IBC Chapter 10 and Florida Building Code modifications.
Focus on both normal and emergency egress scenarios.
```

### B2.02 - Assembly Occupancy Life Safety Specialist
```
Analyze life safety for assembly occupancies:
1. Calculate assembly occupant loads and egress capacity
2. Verify exit arrangement and travel distance requirements
3. Check accessibility seating and egress requirements
4. Verify emergency lighting and communication systems
5. Check crowd control and queue management
6. Generate assembly life safety compliance report

Include theaters, churches, restaurants, and sports facilities.
Reference: IBC Chapter 3 Assembly occupancies and Chapter 10 Egress.
Focus on high-density occupancy safety considerations.
```

### B2.03 - Educational Facility Safety Analyzer
```
Analyze educational facility life safety requirements:
1. Check classroom and corridor egress requirements
2. Verify age-appropriate egress hardware and systems
3. Check emergency lockdown and security provisions
4. Verify fire drill and evacuation procedures
5. Check playground and outdoor area safety
6. Generate educational facility safety compliance report

Include K-12 schools, daycare centers, and higher education.
Reference: IBC Chapter 3 Educational occupancies and state education codes.
Focus on child safety and emergency response procedures.
```

### B2.04 - Healthcare Facility Life Safety Specialist
```
Analyze healthcare facility life safety requirements:
1. Check patient egress and evacuation procedures
2. Verify fire-rated assemblies and smoke barriers
3. Check medical gas and electrical system requirements
4. Verify infection control and isolation requirements
5. Check emergency power and communication systems
6. Generate healthcare life safety compliance report

Include hospitals, clinics, nursing homes, and medical offices.
Reference: IBC Chapter 3 Institutional occupancies and NFPA healthcare standards.
Focus on patient safety and continuity of care.
```

### B2.05 - High-Rise Evacuation Planner
```
Plan high-rise building evacuation procedures:
1. Analyze phased evacuation vs total evacuation strategies
2. Check elevator use for emergency evacuation
3. Verify refuge area and area of rescue assistance
4. Check emergency communication and notification systems
5. Verify fire department access and operations
6. Generate high-rise evacuation plan and procedures

Include office buildings, residential towers, and mixed-use high-rises.
Reference: IBC Chapter 4 High-rise provisions and NFPA emergency procedures.
Focus on occupant safety and fire department coordination.
```

### B2.06 - Residential Egress and Safety Checker
```
Verify residential egress and life safety requirements:
1. Check bedroom egress window requirements
2. Verify stair and guard rail safety requirements
3. Check smoke detection and alarm requirements
4. Verify emergency escape and rescue openings
5. Check carbon monoxide detection requirements
6. Generate residential safety compliance checklist

Include single-family, townhouse, and apartment egress requirements.
Reference: IRC Chapter 3 Building Planning and IBC residential provisions.
Focus on family safety and emergency escape.
```

### B2.07 - Fire Protection System Coordinator
```
Coordinate fire protection systems with building design:
1. Determine fire protection system requirements by occupancy
2. Check sprinkler system coverage and design requirements
3. Verify fire alarm and detection system requirements
4. Check smoke control and management systems
5. Verify fire department connection and access
6. Generate fire protection system coordination report

Include automatic sprinkler, alarm, and suppression systems.
Reference: IBC Chapter 9 Fire Protection Systems and NFPA standards.
Focus on life safety and property protection integration.
```

### B2.08 - Emergency Lighting and Power Systems
```
Design emergency lighting and power systems:
1. Determine emergency lighting requirements by occupancy
2. Check exit sign placement and visibility requirements
3. Verify emergency power system requirements
4. Check battery backup and generator requirements
5. Verify emergency communication system power
6. Generate emergency systems design and compliance report

Include egress lighting, exit signs, and emergency power.
Reference: IBC Chapter 27 Electrical and NFPA emergency lighting standards.
Focus on reliable emergency illumination and power.
```

### B2.09 - Means of Egress Accessibility Checker
```
Verify accessible means of egress compliance:
1. Check accessible route egress requirements
2. Verify area of rescue assistance design and placement
3. Check accessible egress stair and elevator requirements
4. Verify emergency communication in areas of rescue assistance
5. Check accessible parking and drop-off egress
6. Generate accessible egress compliance documentation

Include both ambulatory and non-ambulatory accessibility.
Reference: IBC Chapter 10 Egress and accessibility provisions.
Focus on equal egress access for all occupants.
```

### B2.10 - Occupancy Classification and Mixed-Use Analyzer
```
Analyze occupancy classification and mixed-use requirements:
1. Determine primary and secondary occupancy classifications
2. Check fire separation requirements between occupancies
3. Verify egress requirements for mixed-use buildings
4. Check fire protection system requirements for mixed occupancies
5. Verify accessibility requirements for all occupancies
6. Generate occupancy classification and compliance report

Include business, mercantile, assembly, and residential mixed-use.
Reference: IBC Chapter 3 Occupancy Classification and Chapter 5 General Building Heights and Areas.
Focus on safe and code-compliant mixed-use design.
```

## B3. ACCESSIBILITY & ADA (10 prompts)

### B3.01 - Complete ADA Compliance Auditor
```
Perform comprehensive ADA compliance audit:
1. Check all accessible routes and path of travel
2. Verify parking and passenger drop-off accessibility
3. Check entrance and exit accessibility
4. Verify restroom and facility accessibility
5. Check signage and wayfinding compliance
6. Generate complete ADA compliance certification

Reference: 2010 ADA Standards for Accessible Design
Include both Title II (public) and Title III (private) requirements
Focus on both new construction and alteration compliance
```

### B3.02 - Accessible Route Analyzer
```
Analyze and document accessible routes throughout facility:
1. Map primary accessible route from parking to entrance
2. Check secondary accessible routes to all areas
3. Verify accessible route widths and clearances
4. Check accessible route surfaces and slopes
5. Verify door and opening accessibility along routes
6. Generate accessible route documentation and certification

Include both interior and exterior accessible routes
Reference: ADA Standards Section 206 Accessible Routes
Focus on continuous and unobstructed accessible access
```

### B3.03 - Accessible Parking and Drop-off Designer
```
Design accessible parking and passenger drop-off areas:
1. Calculate required accessible parking spaces
2. Design van-accessible parking space requirements
3. Check accessible parking space and aisle dimensions
4. Verify signage and marking requirements
5. Design accessible passenger drop-off areas
6. Generate parking accessibility compliance documentation

Include both surface parking and garage requirements
Reference: ADA Standards Section 208 Parking Spaces
Focus on convenient and safe accessible parking access
```

### B3.04 - Accessible Restroom Design Specialist
```
Design fully accessible restroom facilities:
1. Check restroom accessibility and clear floor space
2. Verify toilet and urinal accessibility requirements
3. Check sink and mirror accessibility
4. Verify grab bar placement and specifications
5. Check door and hardware accessibility
6. Generate accessible restroom compliance documentation

Include both single-user and multi-user restroom requirements
Reference: ADA Standards Section 213 Toilet Facilities and Bathing Facilities
Focus on usable and dignified accessible restroom design
```

### B3.05 - Vertical Accessibility Specialist
```
Design vertical accessibility systems:
1. Check elevator accessibility and requirements
2. Verify platform lift design and placement
3. Check accessible stair design requirements
4. Verify accessible ramp design and placement
5. Check handrail and guard rail accessibility
6. Generate vertical accessibility compliance documentation

Include both passenger and freight elevator accessibility
Reference: ADA Standards Section 407 Elevators and Section 405 Ramps
Focus on safe and independent vertical access
```

### B3.06 - Fair Housing Act Compliance Checker
```
Verify Fair Housing Act compliance for residential projects:
1. Check accessible entrance and common area requirements
2. Verify accessible route requirements within units
3. Check door and hallway width requirements
4. Verify bathroom and kitchen accessibility
5. Check light switch and control accessibility
6. Generate Fair Housing Act compliance documentation

Include both multifamily and single-family covered housing
Reference: Fair Housing Act Design Manual and HUD requirements
Focus on adaptable and accessible residential design
```

### B3.07 - Workplace Accessibility Optimizer
```
Optimize workplace design for accessibility:
1. Check work surface and equipment accessibility
2. Verify accessible route to all work areas
3. Check accessible parking for employees
4. Verify break room and facility accessibility
5. Check emergency egress accessibility for employees
6. Generate workplace accessibility compliance report

Include both office and industrial workplace requirements
Reference: ADA Standards and ADA Employment provisions
Focus on equal employment opportunity and access
```

### B3.08 - Public Accommodation Accessibility Auditor
```
Audit public accommodations for accessibility compliance:
1. Check retail and restaurant accessibility
2. Verify hotel and lodging accessibility
3. Check recreational facility accessibility
4. Verify healthcare facility accessibility
5. Check transportation facility accessibility
6. Generate public accommodation compliance certification

Include both existing facility barriers and new construction
Reference: ADA Standards Title III Public Accommodations
Focus on equal access to goods and services
```

### B3.09 - Historic Building Accessibility Specialist
```
Design accessibility improvements for historic buildings:
1. Evaluate accessibility barriers in historic buildings
2. Design compatible accessibility improvements
3. Check alternative accessibility solutions
4. Verify preservation vs accessibility balance
5. Coordinate with historic preservation requirements
6. Generate historic accessibility compliance documentation

Include both National Register and local landmark properties
Reference: ADA Standards Section 106 Historic Preservation
Focus on preserving historic character while improving access
```

### B3.10 - Technology and Communication Accessibility
```
Design accessible technology and communication systems:
1. Check assistive listening system requirements
2. Verify visual alarm and notification systems
3. Check accessible parking meter and payment systems
4. Verify elevator and platform lift communication
5. Check website and digital accessibility coordination
6. Generate technology accessibility compliance documentation

Include both built environment and digital accessibility
Reference: ADA Standards Section 219 Assistive Listening Systems
Focus on effective communication for all users
```