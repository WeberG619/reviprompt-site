# ReviPrompt Master Library - 150+ Professional Prompts

## Library Organization

### **TIER 1: Foundation Pack (25 prompts) - $39**
Essential automation for every Revit user

### **TIER 2: Professional Pack (75 prompts) - $149** 
Complete workflow automation + Foundation

### **TIER 3: Enterprise Pack (150+ prompts) - $299**
Full library + custom prompts + support

---

# ARCHITECTURAL DESIGN PROMPTS (45 total)

## A1. DESIGN DEVELOPMENT (10 prompts)

### A1.01 - Residential Massing Analyzer
```
Analyze my residential Revit model for zoning compliance:
1. Calculate total building area and footprint
2. Check setback requirements for [ZONING_TYPE]
3. Verify height restrictions and floor area ratios
4. Generate massing study with 3D views
5. Create compliance report with code citations
6. Flag any violations with specific measurements

Include Florida Building Code references where applicable.
Target: Single-family and multifamily projects up to 7 stories.
```

### A1.02 - Multifamily Unit Mix Optimizer
```
Optimize apartment unit layouts for maximum efficiency:
1. Analyze existing unit plans for area utilization
2. Suggest improvements for [UNIT_TYPE] layouts
3. Calculate net-to-gross ratios by floor
4. Generate unit mix analysis (studio, 1BR, 2BR, 3BR)
5. Optimize corridor efficiency and fire egress
6. Create leasing plan with optimal rent/sf ratios

Focus on [MARKET_TYPE]: Luxury, Mid-range, or Affordable housing.
Include ADA unit distribution requirements.
```

### A1.03 - Hotel Design Program Validator
```
Validate hotel design program against industry standards:
1. Check room count vs required support spaces
2. Verify FF&E areas meet hospitality standards
3. Calculate required parking based on [LOCATION]
4. Analyze back-of-house circulation efficiency
5. Check service area accessibility and code compliance
6. Generate program verification report

Reference: Hotel design standards from actual resort projects.
Include provisions for [STAR_RATING] requirements.
```

### A1.04 - Commercial Space Planning Assistant
```
Optimize commercial floor plate layouts:
1. Analyze rentable vs usable square footage
2. Calculate core efficiency ratios
3. Optimize tenant demising for [TENANT_TYPE]
4. Check ADA compliance for all spaces
5. Verify egress paths and occupant loads
6. Generate leasing plan with CAD boundaries

Target building types: Office, retail, mixed-use.
Include BOMA standards compliance.
```

### A1.05 - Residential Addition Code Checker
```
Analyze residential additions for code compliance:
1. Check existing structure vs proposed addition
2. Verify setback compliance for additions
3. Calculate total lot coverage and FAR
4. Check height restrictions and view corridors
5. Analyze structural implications and foundations
6. Generate permit-ready compliance documentation

Focus on Florida residential codes and hurricane requirements.
Include historic district considerations if applicable.
```

### A1.06 - Church Design Program Analyzer
```
Validate religious facility design requirements:
1. Calculate sanctuary seating vs support spaces
2. Check accessibility requirements for worship
3. Verify life safety and egress for assembly
4. Analyze acoustical considerations and sightlines
5. Check parking requirements for [DENOMINATION]
6. Generate program compliance report

Include considerations for multi-use fellowship spaces.
Reference actual church project experience.
```

### A1.07 - Medical Facility Space Planner
```
Optimize medical office layout efficiency:
1. Check exam room count vs waiting areas
2. Verify ADA compliance for medical facilities
3. Analyze staff circulation vs patient flow
4. Check required support spaces (billing, records)
5. Verify life safety requirements for medical use
6. Calculate parking based on medical use factors

Include HIPAA privacy considerations in layout.
Target: Medical office buildings and clinics.
```

### A1.08 - Adaptive Reuse Feasibility Analyzer
```
Analyze existing buildings for adaptive reuse potential:
1. Evaluate structural capacity for new use
2. Check floor plate efficiency for [NEW_USE]
3. Analyze egress requirements vs existing conditions
4. Calculate renovation costs vs new construction
5. Identify historic preservation constraints
6. Generate feasibility report with recommendations

Focus on converting [EXISTING_USE] to [PROPOSED_USE].
Include zoning change requirements.
```

### A1.09 - Senior Living Design Validator
```
Validate senior housing design requirements:
1. Check unit accessibility vs fair housing requirements
2. Verify common area ratios and programming
3. Analyze circulation for mobility assistance
4. Check dining and activity space adequacy
5. Verify life safety for assisted living
6. Generate compliance report for licensing

Include memory care and independent living considerations.
Reference state licensing requirements for [STATE].
```

### A1.10 - Mixed-Use Development Coordinator
```
Coordinate mixed-use building program requirements:
1. Analyze residential vs commercial parking ratios
2. Check fire separation between uses
3. Verify egress requirements for mixed occupancy
4. Calculate utility demands for multiple uses
5. Analyze shared space opportunities
6. Generate development program summary

Include zoning compliance for mixed-use districts.
Focus on urban infill and transit-oriented development.
```

## A2. DOCUMENTATION AUTOMATION (10 prompts)

### A2.01 - Florida Construction Document Generator
```
Generate complete construction document set:
1. Create all required plan types (site, floor, roof, enlarged)
2. Generate building elevations with material callouts
3. Create building sections at [SCALE]
4. Auto-generate detail callouts and references
5. Create door/window schedules with specifications
6. Generate sheet index and drawing list

Follow Florida Building Code documentation requirements.
Include hurricane tie-down details and flood considerations.
```

### A2.02 - ADA Compliance Documentation Generator
```
Generate comprehensive ADA compliance documentation:
1. Create accessible route plans with dimensions
2. Generate bathroom detail drawings
3. Document parking and drop-off requirements
4. Create signage and wayfinding plans
5. Generate accessibility compliance checklist
6. Produce ADA compliance certificate package

Reference 2010 ADA Standards and Florida Accessibility Code.
Include path of travel analysis and calculations.
```

### A2.03 - Multifamily Life Safety Plans
```
Generate life safety documentation for multifamily:
1. Create fire egress plans with travel distances
2. Generate fire-rated assembly schedules
3. Document fire department access routes
4. Create smoke compartment diagrams
5. Generate fire safety equipment plans
6. Produce life safety compliance report

Follow Florida Fire Prevention Code requirements.
Include hurricane shelter provisions if required.
```

### A2.04 - Commercial Tenant Improvement Package
```
Generate tenant improvement construction documents:
1. Create demolition and new construction plans
2. Generate reflected ceiling plans with MEP coordination
3. Create finish plans and specifications
4. Generate millwork and built-in details
5. Create electrical and data plans
6. Produce permit and bid package

Include base building coordination requirements.
Focus on office and retail tenant improvements.
```

### A2.05 - Single Family Permit Set Generator
```
Generate complete single-family permit drawings:
1. Create site plan with setbacks and utilities
2. Generate floor plans with room labels and areas
3. Create elevations with material specifications
4. Generate foundation and framing plans
5. Create typical details and sections
6. Produce permit application package

Follow local jurisdiction requirements for [COUNTY].
Include hurricane design provisions and flood zones.
```

### A2.06 - Hotel Construction Document Coordinator
```
Generate hotel construction documentation:
1. Create typical floor plans with room numbering
2. Generate public area plans and elevations
3. Create back-of-house and service area plans
4. Generate interior elevations for key spaces
5. Create FF&E plans and specifications
6. Coordinate with consultant drawings

Reference hospitality design standards and accessibility.
Include provisions for [HOTEL_TYPE] requirements.
```

### A2.07 - Renovation Documentation Generator
```
Generate renovation project documentation:
1. Create existing conditions documentation
2. Generate demolition plans with phasing
3. Create new construction plans
4. Generate details showing new-to-existing connections
5. Create temporary protection and staging plans
6. Produce renovation specification package

Include structural implications and code upgrades.
Focus on occupied building renovation challenges.
```

### A2.08 - Landscape Architecture Coordination
```
Coordinate landscape plans with building design:
1. Verify building footprint vs landscape plans
2. Check utility conflicts with planting
3. Coordinate site lighting with landscape
4. Verify accessibility of landscape features
5. Check irrigation conflicts with building systems
6. Generate landscape/architecture coordination report

Include native plant requirements for [REGION].
Focus on sustainable landscape design integration.
```

### A2.09 - Structural Drawing Coordination
```
Coordinate architectural plans with structural:
1. Verify column and beam locations
2. Check floor and roof framing coordination
3. Coordinate penetrations and openings
4. Verify stair and elevator structural requirements
5. Check foundation plans vs architectural
6. Generate structural coordination report

Include seismic and wind design considerations.
Focus on steel and concrete construction types.
```

### A2.10 - MEP Systems Documentation Coordinator
```
Coordinate MEP systems with architectural design:
1. Verify mechanical room sizes and access
2. Check electrical room and panel locations
3. Coordinate plumbing penetrations and chases
4. Verify fire protection system integration
5. Check HVAC equipment access and maintenance
6. Generate MEP coordination report

Include energy code compliance verification.
Focus on system integration and constructability.
```

## A3. PROJECT MANAGEMENT (10 prompts)

### A3.01 - Florida Permit Process Navigator
```
Guide through Florida permit application process:
1. Identify required permits for [PROJECT_TYPE]
2. Generate permit application checklist
3. Create submission package organization
4. Calculate permit fees and timelines
5. Identify required consultants and studies
6. Generate permit tracking schedule

Include specific requirements for [COUNTY/CITY].
Reference hurricane season construction restrictions.
```

### A3.02 - Construction Administration Assistant
```
Manage construction phase documentation:
1. Process RFIs with architectural responses
2. Track change orders and cost implications
3. Generate field observation reports
4. Create punch list organization system
5. Coordinate submittal reviews and approvals
6. Produce construction progress documentation

Include quality control and inspection schedules.
Focus on maintaining design intent through construction.
```

### A3.03 - Client Presentation Package Generator
```
Create professional client presentation materials:
1. Generate design development presentation boards
2. Create 3D renderings and walk-through views
3. Develop material and finish boards
4. Create project timeline and milestone schedule
5. Generate cost estimate summary
6. Produce client decision-making checklists

Include sustainable design features and benefits.
Focus on clear communication of design concepts.
```

### A3.04 - Consultant Coordination Manager
```
Coordinate multidisciplinary design team:
1. Create consultant scope and deliverable matrix
2. Generate coordination meeting agendas
3. Track consultant deliverable schedules
4. Coordinate model sharing and file management
5. Generate design coordination reports
6. Produce integrated project delivery documentation

Include BIM coordination protocols and standards.
Focus on maintaining project schedule and quality.
```

### A3.05 - Code Review Preparation Assistant
```
Prepare for code review and plan check:
1. Generate code analysis summary report
2. Create compliance matrix for all applicable codes
3. Identify potential review comments and responses
4. Generate code official presentation materials
5. Create variance request documentation if needed
6. Produce plan check response strategy

Include specific reviewer preferences for [JURISDICTION].
Focus on proactive issue resolution.
```

### A3.06 - Project Budget and Schedule Tracker
```
Track project costs and schedule performance:
1. Monitor design phase budget vs actual
2. Track consultant fee expenditures
3. Generate schedule variance reports
4. Calculate design change cost implications
5. Monitor permit and approval timelines
6. Produce project financial dashboard

Include earned value analysis and forecasting.
Focus on proactive project management.
```

### A3.07 - Risk Management and Insurance Coordinator
```
Manage project risks and insurance requirements:
1. Identify project-specific risk factors
2. Generate professional liability considerations
3. Coordinate contractor insurance requirements
4. Track permit bond and insurance compliance
5. Document design liability limitations
6. Produce risk mitigation strategy

Include hurricane and flood insurance considerations.
Focus on protecting design team and client interests.
```

### A3.08 - Sustainable Design Documentation
```
Document sustainable design strategies:
1. Calculate energy performance improvements
2. Generate LEED or green building documentation
3. Track sustainable material selections
4. Document water efficiency strategies
5. Calculate carbon footprint reductions
6. Produce sustainability report and certifications

Include Florida Green Building Coalition standards.
Focus on cost-effective sustainability strategies.
```

### A3.09 - Historic Preservation Project Manager
```
Manage historic preservation project requirements:
1. Research historic significance and documentation
2. Coordinate with preservation consultants
3. Generate Section 106 compliance documentation
4. Track tax credit application requirements
5. Coordinate with preservation review boards
6. Produce historic preservation compliance report

Include National Register and local landmark requirements.
Focus on preserving historic character while meeting codes.
```

### A3.10 - Public Agency Project Coordinator
```
Coordinate projects with public agencies:
1. Navigate public procurement and selection processes
2. Generate public meeting and presentation materials
3. Coordinate with multiple stakeholder groups
4. Track public approval and review processes
5. Generate compliance documentation for public projects
6. Produce public project delivery documentation

Include AIA and public contracting requirements.
Focus on transparency and public accountability.
```

## A4. QUALITY CONTROL (10 prompts)

### A4.01 - Drawing Set Quality Auditor
```
Perform comprehensive drawing set quality audit:
1. Check all drawing cross-references and callouts
2. Verify dimension strings and accuracy
3. Check room names, numbers, and areas
4. Verify door and window schedules vs plans
5. Check title block and sheet information consistency
6. Generate quality control report with corrections

Include specific standards for [PROJECT_TYPE].
Focus on construction document accuracy and completeness.
```

### A4.02 - Revit Model Health Analyzer
```
Analyze Revit model for performance and accuracy:
1. Check for warnings and errors in model
2. Verify family parameter consistency
3. Check workset organization and standards
4. Analyze model file size and performance
5. Verify view template applications
6. Generate model health report with recommendations

Include multi-version Revit compatibility checks.
Focus on model efficiency and collaboration.
```

### A4.03 - Code Compliance Checker
```
Verify building code compliance throughout design:
1. Check occupancy classifications and loads
2. Verify egress widths and travel distances
3. Check fire-rated assemblies and separations
4. Verify accessibility compliance
5. Check parking and site requirements
6. Generate code compliance summary report

Reference Florida Building Code and local amendments.
Include energy code and green building requirements.
```

### A4.04 - Specification and Drawing Coordination
```
Coordinate specifications with drawings:
1. Verify material callouts match specifications
2. Check detail references vs specification sections
3. Coordinate finish schedules with spec divisions
4. Verify equipment specifications vs plans
5. Check door and window specifications vs schedules
6. Generate coordination report with discrepancies

Include CSI MasterFormat organization standards.
Focus on eliminating conflicts between documents.
```

### A4.05 - Accessibility Compliance Auditor
```
Audit project for complete accessibility compliance:
1. Check all accessible routes and clearances
2. Verify bathroom and facility accessibility
3. Check parking and site accessibility
4. Verify signage and wayfinding compliance
5. Check elevator and lift requirements
6. Generate ADA compliance certification

Include Fair Housing Act requirements for residential.
Focus on both federal and state accessibility standards.
```

### A4.06 - Construction Coordination Checker
```
Check construction coordination and constructability:
1. Verify structural vs architectural coordination
2. Check MEP vs architectural conflicts
3. Verify ceiling heights and clearances
4. Check material compatibility and connections
5. Verify construction sequence and access
6. Generate constructability report

Include value engineering opportunities.
Focus on reducing construction costs and conflicts.
```

### A4.07 - Energy Code Compliance Validator
```
Validate energy code compliance strategies:
1. Check building envelope performance
2. Verify HVAC system efficiency requirements
3. Check lighting power density compliance
4. Verify renewable energy requirements
5. Check energy modeling vs design
6. Generate energy compliance report

Include Florida Energy Conservation Code requirements.
Focus on cost-effective energy efficiency strategies.
```

### A4.08 - Fire and Life Safety Auditor
```
Audit fire and life safety design compliance:
1. Check egress capacity and travel distances
2. Verify fire-rated assembly requirements
3. Check fire protection system coverage
4. Verify smoke control and management
5. Check emergency communication systems
6. Generate life safety compliance report

Include International Fire Code and NFPA standards.
Focus on occupant safety and fire department access.
```

### A4.09 - Zoning and Planning Compliance Checker
```
Verify zoning and planning code compliance:
1. Check setback and height requirements
2. Verify density and floor area ratios
3. Check parking and loading requirements
4. Verify landscape and open space requirements
5. Check signage and design standard compliance
6. Generate zoning compliance summary

Include overlay districts and special requirements.
Focus on avoiding costly design changes.
```

### A4.10 - Project Close-Out Documentation
```
Generate project close-out documentation package:
1. Create as-built drawing certification
2. Generate warranty and maintenance documentation
3. Create facility management and operations manual
4. Coordinate consultant close-out deliverables
5. Generate project lessons learned report
6. Produce project archive and record documents

Include building commissioning and turnover requirements.
Focus on successful project delivery and client satisfaction.
```

## A5. BIM STANDARDS (5 prompts)

### A5.01 - Revit Template Standardizer
```
Standardize Revit project templates across versions:
1. Create 2024/2025/2026 compatible templates
2. Standardize view templates and graphic standards
3. Set up project parameters and shared parameters
4. Configure family libraries and content
5. Set up workset and collaboration standards
6. Generate template documentation and standards

Include discipline-specific templates (Arch/Struct/MEP).
Focus on consistency and collaboration efficiency.
```

### A5.02 - Family Library Manager
```
Organize and manage Revit family libraries:
1. Audit existing family content and parameters
2. Standardize family naming conventions
3. Convert families to shared parameters
4. Organize families by CSI divisions
5. Create family testing and quality standards
6. Generate family library documentation

Include type catalogs and family loading standards.
Focus on model performance and content management.
```

### A5.03 - BIM Execution Plan Generator
```
Create comprehensive BIM Execution Plan (BEP):
1. Define project information requirements
2. Set up model organization and standards
3. Define collaboration and coordination protocols
4. Set up quality control and validation procedures
5. Define deliverable formats and schedules
6. Generate BEP documentation and training materials

Include Level of Development (LOD) specifications.
Focus on successful project collaboration and delivery.
```

### A5.04 - Model Coordination Manager
```
Manage multi-disciplinary model coordination:
1. Set up coordination model procedures
2. Configure clash detection and reporting
3. Define issue tracking and resolution protocols
4. Set up coordination meeting and review cycles
5. Generate coordination reports and documentation
6. Produce model federation and viewing procedures

Include cloud collaboration and file sharing protocols.
Focus on eliminating coordination conflicts.
```

### A5.05 - Data Management and Archive System
```
Set up project data management and archiving:
1. Configure project file organization standards
2. Set up backup and version control procedures
3. Define project archive and record requirements
4. Configure data security and access controls
5. Set up project handover and close-out procedures
6. Generate data management documentation

Include cloud storage and collaboration requirements.
Focus on data security and long-term accessibility.
```