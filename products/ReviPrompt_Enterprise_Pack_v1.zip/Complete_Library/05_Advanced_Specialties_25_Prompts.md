# ADVANCED SPECIALTY PROMPTS (25 total)

## AS1. COMPUTATIONAL DESIGN (8 prompts)

### AS1.01 - Parametric Design Generator
```
Create parametric design systems in Revit:
1. Set up adaptive families with parametric relationships
2. Create design algorithms using Dynamo
3. Generate multiple design iterations automatically
4. Optimize designs based on performance criteria
5. Create custom parameters for design control
6. Generate parametric design documentation

Include: Mass studies, facade systems, structural optimization
Reference: Dynamo computational design workflows
Focus on: Design exploration and optimization through computation
```

### AS1.02 - Generative Design Optimizer
```
Implement generative design workflows:
1. Define design goals and constraints
2. Set up multi-objective optimization algorithms
3. Generate and evaluate design alternatives
4. Integrate performance analysis (energy, structural, cost)
5. Create decision-making frameworks for design selection
6. Generate generative design reports and recommendations

Include: Space planning, structural layout, envelope optimization
Reference: Autodesk Generative Design and optimization principles
Focus on: AI-assisted design exploration and decision-making
```

### AS1.03 - Performance-Based Design Analyzer
```
Analyze building performance for design optimization:
1. Integrate energy analysis with design iteration
2. Calculate daylighting and solar analysis
3. Analyze structural performance and optimization
4. Calculate cost optimization and value engineering
5. Integrate acoustic and thermal comfort analysis
6. Generate performance-based design recommendations

Include: Passive design strategies and active system optimization
Reference: Building performance simulation and optimization tools
Focus on: Data-driven design decisions for optimal performance
```

### AS1.04 - Facade System Designer
```
Design complex facade systems using computational methods:
1. Create parametric facade panel systems
2. Generate adaptive shading and environmental response
3. Calculate solar orientation and performance optimization
4. Design modular and prefabricated facade components
5. Integrate structural and thermal performance
6. Generate facade system documentation and specifications

Include: Curtain walls, rainscreens, and adaptive facades
Reference: Facade engineering and environmental design principles
Focus on: High-performance and responsive building envelopes
```

### AS1.05 - Complex Geometry and Form Generator
```
Generate and rationalize complex architectural geometries:
1. Create complex curved and twisted geometries
2. Rationalize complex forms for construction
3. Generate panelization and fabrication strategies
4. Calculate structural systems for complex geometry
5. Optimize geometry for performance and constructability
6. Generate complex geometry construction documentation

Include: Parametric surfaces, tensile structures, and freeform architecture
Reference: Computational geometry and digital fabrication principles
Focus on: Buildable complex architecture through digital design
```

### AS1.06 - Digital Fabrication and Construction Automation
```
Design for digital fabrication and construction automation:
1. Create designs optimized for CNC and robotic fabrication
2. Generate fabrication drawings and machine code
3. Design modular systems for automated assembly
4. Calculate material optimization and waste reduction
5. Integrate quality control and dimensional accuracy
6. Generate digital fabrication documentation

Include: 3D printing, CNC cutting, robotic assembly
Reference: Digital fabrication and Industry 4.0 construction methods
Focus on: Precision construction through digital manufacturing
```

### AS1.07 - Data-Driven Design and Analytics
```
Implement data-driven design and analytics workflows:
1. Collect and analyze building performance data
2. Create predictive models for design optimization
3. Integrate real-time sensor data with design models
4. Generate data visualizations and design insights
5. Create feedback loops for continuous design improvement
6. Generate data-driven design recommendations

Include: IoT integration, machine learning, and predictive analytics
Reference: Building analytics and smart building technologies
Focus on: Evidence-based design through data analysis
```

### AS1.08 - Artificial Intelligence Design Assistant
```
Integrate AI and machine learning in design workflows:
1. Train AI models on design precedents and performance data
2. Generate design suggestions using machine learning
3. Automate routine design tasks with AI assistance
4. Create intelligent design validation and error checking
5. Implement natural language design interfaces
6. Generate AI-assisted design documentation

Include: Design pattern recognition, automated optimization, and intelligent assistance
Reference: AI in architecture and machine learning applications
Focus on: Enhanced design capability through artificial intelligence
```

## AS2. SUSTAINABILITY & RESILIENCE (8 prompts)

### AS2.01 - Net Zero Energy Building Designer
```
Design net zero energy buildings:
1. Calculate building energy use intensity (EUI) targets
2. Design passive solar and natural ventilation strategies
3. Optimize building envelope performance
4. Size renewable energy systems for net zero
5. Design energy storage and smart grid integration
6. Generate net zero energy certification documentation

Include: LEED, Living Building Challenge, and ENERGY STAR requirements
Reference: ASHRAE, DOE, and green building standards
Focus on: Achieving carbon neutrality through integrated design
```

### AS2.02 - Climate Resilience and Adaptation Planner
```
Design climate-resilient buildings and communities:
1. Analyze climate change impacts and projections
2. Design flood-resistant and storm-resilient structures
3. Calculate heat island mitigation and cooling strategies
4. Design water management and drought resilience
5. Plan for sea level rise and coastal adaptation
6. Generate climate resilience planning documentation

Include: FEMA resilience guidelines and climate adaptation strategies
Reference: Climate science and resilience planning standards
Focus on: Future-proofing buildings against climate change
```

### AS2.03 - Circular Economy and Material Health
```
Implement circular economy principles in building design:
1. Analyze material lifecycle and environmental impact
2. Design for disassembly and material reuse
3. Select healthy and non-toxic building materials
4. Calculate embodied carbon and carbon sequestration
5. Design material recovery and recycling systems
6. Generate circular design and material health documentation

Include: Cradle to Cradle, Material Health Certificate, and LCA principles
Reference: Ellen MacArthur Foundation and material health standards
Focus on: Regenerative design and healthy material ecosystems
```

### AS2.04 - Biophilic and Nature-Based Design
```
Design biophilic and nature-integrated buildings:
1. Integrate natural elements and systems into building design
2. Design living walls and green roof systems
3. Calculate biodiversity and ecosystem service benefits
4. Design natural ventilation and lighting systems
5. Create connections to nature and outdoor spaces
6. Generate biophilic design guidelines and benefits documentation

Include: WELL Building Standard and biophilic design principles
Reference: Biophilia research and nature-based solution standards
Focus on: Human health and well-being through nature integration
```

### AS2.05 - Water Security and Management
```
Design comprehensive water security and management systems:
1. Calculate water demand and supply balancing
2. Design rainwater harvesting and stormwater management
3. Calculate wastewater treatment and reuse systems
4. Design drought-resilient water systems
5. Integrate smart water monitoring and controls
6. Generate water security planning documentation

Include: Greywater systems, permeable paving, and water-sensitive design
Reference: EPA water efficiency and local water management standards
Focus on: Water independence and resilient water systems
```

### AS2.06 - Renewable Energy and Microgrid Design
```
Design renewable energy and microgrid systems:
1. Calculate solar, wind, and other renewable energy potential
2. Design energy storage and battery systems
3. Calculate microgrid controls and energy management
4. Design grid-tie and islanding capabilities
5. Integrate electric vehicle charging and storage
6. Generate renewable energy system design and economics

Include: Community energy systems and peer-to-peer energy trading
Reference: IEEE microgrid standards and renewable energy codes
Focus on: Energy independence and grid resilience
```

### AS2.07 - Carbon Neutral and Sequestration Design
```
Design carbon neutral and carbon sequestering buildings:
1. Calculate building lifecycle carbon emissions
2. Design carbon sequestration through materials and landscaping
3. Calculate operational carbon reduction strategies
4. Design regenerative systems that sequester carbon
5. Integrate carbon monitoring and verification systems
6. Generate carbon neutral certification documentation

Include: Embodied carbon, operational carbon, and carbon offsets
Reference: Carbon accounting standards and climate action frameworks
Focus on: Net negative carbon impact through integrated design
```

### AS2.08 - Community Resilience and Social Sustainability
```
Design for community resilience and social sustainability:
1. Analyze community vulnerability and adaptive capacity
2. Design community gathering and emergency response spaces
3. Calculate economic development and job creation impacts
4. Design affordable and equitable housing strategies
5. Plan community food systems and urban agriculture
6. Generate community resilience planning documentation

Include: Social impact assessment and community engagement strategies
Reference: UN Sustainable Development Goals and community resilience frameworks
Focus on: Equitable and resilient community development
```

## AS3. TECHNOLOGY INTEGRATION (9 prompts)

### AS3.01 - Smart Building and IoT Integration
```
Design smart building and IoT systems:
1. Design building automation and control systems
2. Integrate IoT sensors and monitoring systems
3. Calculate smart building energy management
4. Design occupant experience and comfort optimization
5. Integrate predictive maintenance and building analytics
6. Generate smart building system specifications

Include: Building management systems, sensor networks, and data analytics
Reference: Smart building standards and IoT protocols
Focus on: Intelligent and responsive building operations
```

### AS3.02 - Building Information Modeling (BIM) Advanced Workflows
```
Implement advanced BIM workflows and processes:
1. Design 4D scheduling and construction sequencing
2. Integrate 5D cost modeling and quantity takeoffs
3. Create facility management and operation BIM models
4. Design model-based quality control and validation
5. Integrate reality capture and as-built modeling
6. Generate advanced BIM execution plans

Include: Model-based estimating, clash detection, and lifecycle modeling
Reference: buildingSMART standards and BIM execution planning
Focus on: Comprehensive building lifecycle information management
```

### AS3.03 - Virtual and Augmented Reality Design Tools
```
Implement VR/AR in design and construction processes:
1. Create immersive design review and visualization
2. Design AR-assisted construction and quality control
3. Calculate VR training and safety simulation
4. Design virtual collaboration and remote design review
5. Integrate real-time design modification in VR
6. Generate VR/AR implementation strategies

Include: Design review, construction training, and facility management
Reference: VR/AR industry standards and implementation best practices
Focus on: Enhanced design communication and construction efficiency
```

### AS3.04 - Digital Twin and Building Analytics
```
Create digital twins and building analytics systems:
1. Design digital twin models with real-time data integration
2. Integrate predictive analytics and machine learning
3. Calculate building performance optimization algorithms
4. Design occupant behavior analysis and response
5. Create predictive maintenance and fault detection
6. Generate digital twin implementation and analytics reports

Include: Sensor integration, data analytics, and predictive modeling
Reference: Digital twin frameworks and building analytics standards
Focus on: Continuous building optimization through digital modeling
```

### AS3.05 - Blockchain and Distributed Ledger Applications
```
Implement blockchain technology in building and construction:
1. Design blockchain-based supply chain tracking
2. Create smart contracts for construction and facility management
3. Calculate carbon credit and sustainability token systems
4. Design decentralized energy trading and management
5. Integrate blockchain-based building certification
6. Generate blockchain implementation strategies

Include: Supply chain transparency, automated payments, and verification
Reference: Blockchain standards and distributed ledger technologies
Focus on: Trust and transparency in building lifecycle processes
```

### AS3.06 - Robotics and Automation in Construction
```
Design for robotic construction and automation:
1. Design buildings optimized for robotic construction
2. Calculate robotic assembly and prefabrication systems
3. Design automated material handling and logistics
4. Calculate quality control and inspection automation
5. Integrate safety systems for human-robot collaboration
6. Generate robotic construction implementation plans

Include: 3D printing, robotic assembly, and automated inspection
Reference: Robotics standards and construction automation protocols
Focus on: Precision and efficiency through construction robotics
```

### AS3.07 - Advanced Materials and Nanotechnology
```
Integrate advanced materials and nanotechnology:
1. Design self-healing and adaptive building materials
2. Calculate smart glass and responsive envelope systems
3. Design aerogel and super-insulating materials
4. Calculate photocatalytic and air-purifying materials
5. Integrate shape-memory alloys and smart materials
6. Generate advanced materials specifications and applications

Include: Bio-based materials, smart composites, and responsive systems
Reference: Materials science and nanotechnology applications
Focus on: Next-generation building performance through advanced materials
```

### AS3.08 - Cybersecurity and Building System Protection
```
Design cybersecurity for building systems:
1. Analyze building system cyber vulnerabilities
2. Design network security and access controls
3. Calculate incident response and recovery procedures
4. Design privacy protection for occupant data
5. Integrate security monitoring and threat detection
6. Generate cybersecurity policies and procedures

Include: OT security, IoT device protection, and data privacy
Reference: Cybersecurity frameworks and building system security standards
Focus on: Secure and resilient smart building operations
```

### AS3.09 - Future Technology Integration and Innovation
```
Plan for future technology integration and innovation:
1. Analyze emerging technology trends and applications
2. Design flexible infrastructure for technology evolution
3. Calculate technology ROI and implementation strategies
4. Design innovation testing and pilot programs
5. Create technology roadmaps and planning frameworks
6. Generate future-ready building design strategies

Include: Emerging technologies, innovation frameworks, and adaptability
Reference: Technology forecasting and innovation management principles
Focus on: Future-proofing buildings for technological advancement
```