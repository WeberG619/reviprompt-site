# ReviPrompt Lab - FREE Sampler Pack

## 3 Professional AI Prompts to Transform Your Revit Workflow

### 🎁 **100% Free - No Credit Card Required**

Welcome to ReviPrompt Lab! This free sampler gives you a taste of how AI can automate your most annoying Revit tasks.

---

## 🚀 **What's Included:**

### **1. Sheet Setup Master (Simplified)**
**The Problem**: Spending hours fixing title blocks and renumbering sheets  
**Time Saved**: 2 hours → 2 minutes

**AI PROMPT**:
```
Help me standardize sheets in my Revit project:
1. List all sheets with current numbers and names
2. Suggest a logical renumbering scheme starting with [START_NUMBER]
3. Create a Dynamo script to update sheet numbers sequentially
4. Include error handling for duplicate numbers
5. Generate a sheet index on a cover sheet

Variables to replace:
- [START_NUMBER]: Your starting sheet number (e.g., "A101")

Target: Revit 2024-2026
Output: Dynamo Python script
```

---

### **2. Missing Tag Finder**
**The Problem**: Manually hunting for untagged doors, windows, and rooms  
**Time Saved**: 3 hours → 5 minutes

**AI PROMPT**:
```
Find all untagged elements in my Revit project:
1. Scan all views for doors without tags
2. Identify windows missing tags
3. Find rooms without room tags
4. List the view name and element count for each
5. Create a Dynamo script to automatically place missing tags

Focus on maintaining tag positions that don't overlap.
Generate both a report and an auto-tagging solution.
Compatible with Revit 2024-2026.
```

---

### **3. Area Calculator Pro**
**The Problem**: Manually calculating and updating area schedules  
**Time Saved**: 1 hour → 30 seconds

**AI PROMPT**:
```
Calculate and organize all areas in my Revit project:
1. Sum total area by department/zone parameter
2. Calculate rentable vs non-rentable areas
3. Generate area breakdown by floor level
4. Check areas against program requirements
5. Export results to Excel with formatting

Create a reusable Dynamo script that updates automatically.
Include BOMA calculation methods if commercial project.
Target: Revit 2024-2026
```

---

## 💡 **How to Use These Prompts:**

### **Step 1: Copy the Prompt**
Select any prompt above and copy the entire text

### **Step 2: Open Your AI Assistant**
- ChatGPT: chat.openai.com
- Claude: claude.ai  
- Copilot: Built into Windows/Office

### **Step 3: Paste and Customize**
- Paste the prompt
- Replace [BRACKETS] with your values
- Hit enter

### **Step 4: Run the Generated Code**
- Copy the code the AI generates
- Paste into Dynamo Python node
- Run and save hours!

---

## 🎯 **Why These 3 Prompts?**

We chose these specific prompts because they:
- Solve universal Revit pain points
- Work on any project type
- Show immediate time savings
- Require no special setup
- Demonstrate our prompt quality

---

## 🔥 **Want More? Upgrade to Full Packs:**

### **Foundation Pack - $39** (Save $10 with code: SAMPLER10)
✅ 25 essential prompts covering:
- Complete sheet automation
- Quality control suite
- Florida Building Code compliance
- ADA accessibility checking
- Life safety analysis

### **Professional Pack - $149** (Save $20 with code: SAMPLER20)
✅ 75 total prompts including:
- Everything in Foundation
- Project management automation
- Advanced code compliance
- BIM coordination tools
- Video tutorials (90 min)

### **Enterprise Pack - $299** (Save $50 with code: SAMPLER50)
✅ 150+ prompts featuring:
- Complete architectural library
- MEP system automation
- Structural engineering
- Computational design
- Commercial license (10 users)

---

## 📊 **What Our Customers Say:**

> *"The free sheet setup prompt alone saved me 2 hours. Bought the Pro pack immediately."*  
> — Sarah M., Project Architect

> *"Finally, AI prompts that actually work with real projects."*  
> — Mike D., BIM Manager

> *"ROI in the first day. Wish I found this sooner."*  
> — Lisa K., Design Director

---

## 🎁 **Your Free Bonuses:**

### **1. Revit AI Cheat Sheet**
Quick reference for using AI with Revit effectively

### **2. Discord Community Access**
Join 500+ Revit users automating their workflows

### **3. Weekly Tips Newsletter**
New automation ideas delivered to your inbox

---

## 📞 **Need Help?**

### **Free Support:**
- Email: support@revipromptlab.com
- Discord: discord.gg/revipromptlab
- Documentation: revipromptlab.com/docs

### **Ready for More?**
- Browse all packs: revipromptlab.com/products
- Book a demo: calendly.com/revipromptlab
- Custom prompts: enterprise@revipromptlab.com

---

## 🚀 **Start Automating Now!**

Don't wait - copy your first prompt above and see the magic happen. Your competition is already using AI to work faster. Join them or get left behind.

**Download link expires in 30 days - Save this file!**

---

*© 2024 ReviPrompt Lab LLC | Made by Revit users for Revit users*